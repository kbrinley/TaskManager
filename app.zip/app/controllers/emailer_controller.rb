#class EmailerController < ApplicationController
#  
#  def sendmail
##    #email = @params["email"]
#    recipient = "kbrinley@gmail.com" #params["recipient"]
##    subject = "Test" #params["subject"]
 #   message = "This is a hard coded test" #params["message"]
#    Emailer.deliver_contact(recipient, subject, message)
#    return if request.xhr?
#    render :text => 'Message sent successfully'
#  end
#  
#  def index
    #render :file => 'app\views\emailer\index.rhtml'
#  end
#end
